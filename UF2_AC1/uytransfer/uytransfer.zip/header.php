<header class="navbar row bg-secondary" style="font-family: Acme">
    <h1 class="col-md col-12 pl-5 text-md-left text-center">Uy!Transfer</h1>
    <div class="col-md col-12 text-center">
        <a href="index.php" class="col border-right border-dark text-dark">Enviar archivo</a>
        <a href="upload.php" class="col text-dark">Mis últimos archivos</a>
    </div>
</header>